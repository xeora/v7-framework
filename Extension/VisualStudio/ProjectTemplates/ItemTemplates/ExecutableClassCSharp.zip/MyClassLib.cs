﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Xeora.Web.Shared;

namespace $rootnamespace$
{
    public class $safeitemname$ : IDomainExecutable
    {
        public void Initialize()
        {
        }

        public void Finalize()
        {
        }

        public void PostExecute(string ExecutionID, ref object Result)
        {
        }

        public void PreExecute(string ExecutionID, ref MethodInfo MI)
        {
        }

        public URLMapping.ResolvedMapped URLResolver(string RequestFilePath)
        {
            return null;
        }
    }
}
